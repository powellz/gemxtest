/*
 * sysfs for the device attributes.
 *
 * Copyright (C) 2016-2017 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *    Lizhi Hou <lizhih@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include "mgmt-core.h"
#include <linux/module.h>

#define	MGMT_MB_MAX_RETRY	50
#define MGMT_MB_RETRY_INTERVAL	100       //ms

int mgmt_fini_mb(struct xclmgmt_dev *lro)
{
	
	int	retry = 0;

	if (!lro->mb_on) {
		return 0;
	}

	if (MGMT_READ_REG32(lro, MB_REG_ID) == MB_VALID_ID &&
	    !(MGMT_READ_REG32(lro,MB_REG_STATUS) & MB_STATUS_MASK_STOPPED)) {
		// need to stop microblaze
		mgmt_info(lro, "stopping microblaze...");
		MGMT_WRITE_REG32(lro, MB_REG_CTL, MB_CTL_MASK_STOP);
		MGMT_WRITE_REG32(lro, MB_REG_STOP_CONFIRM, 1);
		while (retry++ < MGMT_MB_MAX_RETRY && !(MGMT_READ_REG32(lro,
		    MB_REG_STATUS) & MB_STATUS_MASK_STOPPED)) {
			msleep(MGMT_MB_RETRY_INTERVAL);
		}
		if (retry >= MGMT_MB_MAX_RETRY) {
			mgmt_err(lro, "Failed to stop microblaze\n");
			return -EIO;
		}
		mgmt_info(lro, "Microblaze Stopped, retry %d\n", retry);
	}

	return 0;
}

int mgmt_init_mb(struct xclmgmt_dev *lro)
{
	u32	mb_id;
	int	ret;

	if ((lro->header.FeatureBitMap & BOARD_MGMT_ENBLD) ||
	    (lro->header.FeatureBitMap & MB_SCHEDULER)) {
		mgmt_info(lro, "Microblaze is supported.");
		lro->mb_on = true;
	} else {
		mgmt_info(lro, "Microblaze is not supported.");
		return 0;
	}

	ret = mgmt_fini_mb(lro);
	if (ret) {
		return ret;
	}

	//Once stopped we can hold the microblaze in reset
	MGMT_WRITE_REG32(lro, MB_GPIO, MB_GPIO_RESET);
	if (lro->header.FeatureBitMap & BOARD_MGMT_ENBLD) {
		mgmt_info(lro, "Copying mgmt image len %d\n",
		    lro->mb_stash.mgmt_binary_length);
		MGMT_TOIO(lro, MB_IMAGE, lro->mb_stash.mgmt_binary,
		    lro->mb_stash.mgmt_binary_length);
	}
	MGMT_WRITE_REG32(lro, MB_GPIO, MB_GPIO_DEFAULT);
	msleep(200);

	mb_id = MGMT_READ_REG32(lro, MB_REG_ID);
	lro->mb_cap = MGMT_READ_REG32(lro, MB_REG_CAP);
	mgmt_info(lro, "Microblaze Ver: %x ID: %x CAP: %x",
		MGMT_READ_REG32(lro, MB_REG_VERSION), mb_id, lro->mb_cap);

	return 0;
}
