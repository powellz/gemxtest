/**
 * Compute unit execution, interrupt management and client context core data structures.
 *
 * Copyright (C) 2017 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *    Sonal Santan <sonal.santan@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef _XCL_XOCL_EXEC_H_
#define _XCL_XOCL_EXEC_H_

#include <linux/mutex.h>
#include <linux/init_task.h>
#include <linux/list.h>
#include <linux/wait.h>

#define XOCL_CU_INTR0 0
#define XOCL_CU_INTR1 1
#define XOCL_CU_INTR2 2
#define XOCL_CU_INTR3 3

#define XOCL_USER_INTR_START 4
#define XOCL_USER_INTR_END 16

#define XOCL_MB_CMD_QUEUE_BASE 0x150000
#define XOCL_MB_STATUS_BASE    0x172000
#define XOCL_MB_SLOT_SIZE      0x1000

struct eventfd_ctx;
struct drm_xocl_bo;
struct drm_xocl_dev;
struct drm_xocl_client_ctx;

/*
 * Plugin structure for scheduler operation. Today we have two backends:
 * 1. Microblaze based embedded scheduler
 * 2. Emulation of microblaze style scheduler running inside xocl driver
 */
struct drm_xocl_sched_ops {
	int (*init) (struct drm_xocl_dev *xdev);
	int (*submit) (struct drm_xocl_dev *xdev, struct drm_xocl_bo *xobj, int slot);
	unsigned int (*query) (struct drm_xocl_dev *xdev);
	int (*callback) (struct drm_xocl_dev *xdev);
	int (*fini) (struct drm_xocl_dev *xdev);
};


struct drm_xocl_client_ctx {
	struct list_head    link;
	atomic_t            trigger;
	/*
	 * Bitmap to indicate all the user interrupts registered. These are unmanaged
	 * interrupts directly used by the non-OpenCL application. The corresponding
	 * eventfd objects are stored in drm_xocl_dev::user_msix_table
	 */
	unsigned int        eventfd_bitmap;
	struct mutex        lock;
};

struct drm_xocl_exec_core {
	/* eventfd table for user interupts */
	struct eventfd_ctx        *user_msix_table[16];
	/* eventfd table lock */
	struct mutex               user_msix_table_lock;
	struct task_struct        *test_kthread;
	struct task_struct        *scheduler_kthread;
	spinlock_t	           ctx_list_lock;
	struct list_head           ctx_list;
	spinlock_t	           cmd_lock;
	/* Slot stores the submitted exec commands */
	struct drm_xocl_bo        *cmd_slot[32];
	/* Bitmap tracks busy/free slots in cmd_slot*/
	unsigned long              cmd_bitmap;
	wait_queue_head_t          poll_wait_queue;
	struct drm_xocl_sched_ops *ops;
};

int xocl_init_exec(struct drm_xocl_dev *xdev);
int xocl_fini_exec(struct drm_xocl_dev *xdev);

int xocl_init_test_thread(struct drm_xocl_dev *xdev);
int xocl_fini_test_thread(struct drm_xocl_dev *xdev);

void xocl_track_ctx(struct drm_xocl_dev *xdev, struct drm_xocl_client_ctx *fpriv);
void xocl_untrack_ctx(struct drm_xocl_dev *xdev, struct drm_xocl_client_ctx *fpriv);

#endif
