/*
 * A GEM style device manager for PCIe based OpenCL accelerators.
 *
 * Copyright (C) 2017 Xilinx, Inc. All rights reserved.
 *
 * Authors:
 *    Sonal Santan <sonal.santan@xilinx.com>
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

//TODO: Hook up drm_event_reserve_init() and drm_send_event() inplace of eventfd

#include <linux/bitops.h>
#include <linux/swap.h>
#include <linux/dma-buf.h>
#include <linux/version.h>
#include <linux/eventfd.h>
#if LINUX_VERSION_CODE <= KERNEL_VERSION(3,0,0)
#include <drm/drm_backport.h>
#endif
#include <drm/drmP.h>
#include "xocl_drv.h"
#include "xocl_ioctl.h"
#include "xocl_xdma.h"

static int xocl_cu_event(struct drm_xocl_dev *xdev);

static inline void release_slot(struct drm_xocl_dev *xdev, unsigned slot)
{
	unsigned long flags;
	unsigned long result = 1ul << slot;
	result = ~result;
	spin_lock_irqsave(&xdev->exec.cmd_lock, flags);
	xdev->exec.cmd_bitmap &= result;
	spin_unlock_irqrestore(&xdev->exec.cmd_lock, flags);
}


/**
 * Called by xocl_xdma_user_isr() which is our stub for user ISR registered with libxdma
 * Kernel doc says eventfd_signal() does not sleep so it should be okay to call this in ISR
 * TODO: Add support for locking so xdev->user_msix_table[irq] is not deleted/changed by
 * xocl_user_intr_ioctl() while we are using it.
 */
int xocl_user_event(int irq, struct drm_xocl_dev *xdev)
{
	if (irq == XOCL_CU_INTR0)
		return xdev->exec.ops->callback(xdev);
	if (!xdev->exec.user_msix_table[irq])
		return -EFAULT;
	if (eventfd_signal(xdev->exec.user_msix_table[irq], 1) == 1)
		return 0;
	return -EFAULT;
}

/**
 * Walk all the slots with valid exec bos. Foreach valid exec bo which has finished
 * as indicated by the status register:
 * 1. change the internal state to complete
 * 2. release the our reference to the bo
 * 3. change the client visible status to done
 * 4. release the bit field in the slot bitmap
 */
static int xocl_retire_done_execs(struct drm_xocl_dev *xdev, unsigned int status)
{
	int slot;
	int index = 1;

	for (slot = 0; slot < 32; slot++) {
		index <<= slot;
		if ((index & status) == 0) continue;
		BUG_ON(!xdev->exec.cmd_slot[slot]);
		BUG_ON(xdev->exec.cmd_slot[slot]->metadata.state != DRM_XOCL_EXECBUF_STATE_QUEUED);
		xdev->exec.cmd_slot[slot]->metadata.state = DRM_XOCL_EXECBUF_STATE_COMPLETE;
		*(unsigned *)xdev->exec.cmd_slot[slot]->vmapping = DRM_XOCL_EXECBUF_STATE_COMPLETE;
		drm_gem_object_unreference_unlocked(&xdev->exec.cmd_slot[slot]->base);
		xdev->exec.cmd_slot[slot] = NULL;
		/* to be safe release the slot bit field at the end */
		release_slot(xdev, slot);
	}
	return 0;
}

static int xocl_cu_event(struct drm_xocl_dev *xdev)
{
	struct list_head *ptr;
	struct drm_xocl_client_ctx *entry;
	unsigned long flags;
	unsigned int status = xdev->exec.ops->query(xdev);

	xocl_retire_done_execs(xdev, status);
	/* now for each client update the trigger counter in the context */
	spin_lock_irqsave(&xdev->exec.ctx_list_lock, flags);
	list_for_each(ptr, &xdev->exec.ctx_list) {
		entry = list_entry(ptr, struct drm_xocl_client_ctx, link);
		atomic_inc(&entry->trigger);
	}
	spin_unlock_irqrestore(&xdev->exec.ctx_list_lock, flags);
	/* wake up all the clients */
	wake_up_interruptible(&xdev->exec.poll_wait_queue);
	return 0;
}

void xocl_track_ctx(struct drm_xocl_dev *xdev, struct drm_xocl_client_ctx *fpriv)
{
	unsigned long flags;

	spin_lock_irqsave(&xdev->exec.ctx_list_lock, flags);
	list_add_tail(&fpriv->link, &xdev->exec.ctx_list);
	spin_unlock_irqrestore(&xdev->exec.ctx_list_lock, flags);
}

void xocl_untrack_ctx(struct drm_xocl_dev *xdev, struct drm_xocl_client_ctx *fpriv)
{
	unsigned long flags;

	spin_lock_irqsave(&xdev->exec.ctx_list_lock, flags);
	list_del(&fpriv->link);
	spin_unlock_irqrestore(&xdev->exec.ctx_list_lock, flags);
}

static int mb_init(struct drm_xocl_dev *xdev)
{
	return 0;
}

static int mb_submit(struct drm_xocl_dev *xdev, struct drm_xocl_bo *xobj, int slot)
{
	memcpy_toio(xdev->user_bar + XOCL_MB_CMD_QUEUE_BASE + slot * XOCL_MB_SLOT_SIZE,
		    xobj->vmapping, XOCL_MB_SLOT_SIZE);
	return 0;
}

static unsigned int mb_query(struct drm_xocl_dev *xdev)
{
	return ioread32(xdev->user_bar + XOCL_MB_STATUS_BASE);
}

static int mb_callback(struct drm_xocl_dev *xdev)
{
	return xocl_cu_event(xdev);
}

static int mb_finish(struct drm_xocl_dev *xdev)
{
	return 0;
}

static int penguin_init(struct drm_xocl_dev *xdev)
{
	return 0;
}

static int penguin_submit(struct drm_xocl_dev *xdev, struct drm_xocl_bo *xobj, int slot)
{
	return 0;
}

static unsigned int penguin_query(struct drm_xocl_dev *xdev)
{
	return 0;
}

static int penguin_callback(struct drm_xocl_dev *xdev)
{
	return 0;
}

static int penguin_finish(struct drm_xocl_dev *xdev)
{
	return 0;
}

/*
 * Embedded scheduler operations
 */
static struct drm_xocl_sched_ops mb_ops = {
	.init = mb_init,
	.submit = mb_submit,
	.query = mb_query,
	.callback = mb_callback,
	.fini = mb_finish
};

/*
 * Fallback xocl driver resident scheduler operations
 */
static struct drm_xocl_sched_ops penguin_ops = {
	.init = penguin_init,
	.submit = penguin_submit,
	.query = penguin_query,
	.callback = penguin_callback,
	.fini = penguin_finish
};


int xocl_init_exec(struct drm_xocl_dev *xdev)
{
	mutex_init(&xdev->exec.user_msix_table_lock);
	spin_lock_init(&xdev->exec.ctx_list_lock);
	INIT_LIST_HEAD(&xdev->exec.ctx_list);
	spin_lock_init(&xdev->exec.cmd_lock);
	/* Only low 32 bits are used in the 64 bit bitmap */
	xdev->exec.cmd_bitmap = ~0ull;
	xdev->exec.cmd_bitmap -= 0xffffffff;
#ifdef XOCL_BUILTIN_TEST
	xocl_init_test_thread(xdev);
#endif
	//xocl_init_scheduler_thread(xdev);
	xdma_user_interrupt_config(xdev, XOCL_CU_INTR0, true);
	init_waitqueue_head(&xdev->exec.poll_wait_queue);
	xdev->exec.ops = &mb_ops;
	xdev->exec.ops->init(xdev);
	return 0;
}

int xocl_fini_exec(struct drm_xocl_dev *xdev)
{
	int i;

	xdev->exec.ops->fini(xdev);
	xdma_user_interrupt_config(xdev, XOCL_CU_INTR0, false);
#ifdef XOCL_BUILTIN_TEST
	xocl_fini_test_thread(xdev);
#endif
	for (i = 0; i < 16; i++) {
		xdma_user_interrupt_config(xdev, i, false);
		if (xdev->exec.user_msix_table[i])
			eventfd_ctx_put(xdev->exec.user_msix_table[i]);
	}
	mutex_destroy(&xdev->exec.user_msix_table_lock);
	return 0;
}
