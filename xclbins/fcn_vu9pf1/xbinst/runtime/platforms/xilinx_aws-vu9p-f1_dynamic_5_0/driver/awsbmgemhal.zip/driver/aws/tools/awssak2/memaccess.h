/**
 * Copyright (C) 2017 Xilinx, Inc
 * Author: Sonal Santan
 * Simple command line utility to inetract with SDX PCIe devices
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may
 * not use this file except in compliance with the License. A copy of the
 * License is located at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string>

#include "driver/include/xclhal2.h"
namespace xcldev {
  class memaccess {
    xclDeviceHandle mHandle;
    size_t mDDRSize, mDataAlignment;
  public:
    memaccess(xclDeviceHandle aHandle, size_t aDDRSize, size_t aDataAlignment) :
              mHandle(aHandle), mDDRSize(aDDRSize), mDataAlignment (aDataAlignment) {}

    int read(std::string aFilename, unsigned long long aStartAddr = 0, unsigned long long aSize = 0) {
      void *buf = 0;
      unsigned long long size;
      unsigned long long blockSize = 0x20000;
      if (posix_memalign(&buf, 4096, blockSize))
        return -1;
      std::memset(buf, 0, blockSize);

      //sanity check
      if (aStartAddr > mDDRSize) {
        std::cout << "Start address " << std::hex << aStartAddr <<
        " is greater than device memory " << std::hex << mDDRSize << std::endl;
        return -1;
      }
      //sanity check
      if (aSize > mDDRSize || aStartAddr+aSize > mDDRSize) {
        std::cout << "Read size " << std::dec << aSize << " from address 0x" << std::hex << aStartAddr <<
          " goes beyond the device memory" << std::endl;
        return -1;
      }

      unsigned long long endAddr = aSize == 0 ? mDDRSize : aStartAddr+aSize;

      size = endAddr-aStartAddr;
      std::ofstream outFile(aFilename, std::ofstream::out | std::ofstream::binary);

      // Use plain POSIX open/pwrite/close.
      size_t count = size;
      uint64_t incr;
      for (uint64_t phy = aStartAddr; phy < aStartAddr+size; phy += incr) {
        incr = (count >= blockSize) ? blockSize : count;
        //std::cout << "Reading from addr " << std::hex << phy << " size = " << std::hex << incr << std::dec << std::endl;
        if (xclUnmgdPread(mHandle, 0, buf, incr, phy) < 0) {
          //error
          std::cout << "Error (" << strerror (errno) << ") reading 0x" << std::hex << incr << " bytes from DDR at offset 0x" << std::hex << phy << std::dec << "\n";
          return -1;
        }
        count -= incr;
        if (incr) {
          outFile.write((const char*)(char*)buf, incr);
          if ((outFile.rdstate() & std::ifstream::failbit) != 0) {
            std::cout << "Error writing to file \n";
          }
        }
        std::cout << "INFO: Read block 0x" << std::hex << incr << " total 0x" <<size-count << std::endl;
      }
      if (count != 0) {
        std::cout << "Error! Read " << std::dec << size-count << " bytes, requested " << size << std::endl;
        return -1;
      }
      std::cout << "INFO: Written " << std::dec << size << " bytes "
        << " to file " << aFilename << std::endl;
      outFile.close();
      free(buf);
      return count;
    }

    int write(unsigned long long aStartAddr, unsigned long long aSize, unsigned int aPattern) {
      void *buf = 0;
      unsigned long long endAddr;
      unsigned long long size;
      unsigned long long blockSize = 0x20000;
      if (posix_memalign(&buf, 4096, blockSize))
        return -1;

      //sanity check
      if (aStartAddr > mDDRSize) {
        std::cout << "Start address " << std::hex << aStartAddr <<
           " is greater than device memory " << std::hex << mDDRSize << std::endl;
        return -1;
      }
      //sanity check
      if (aSize > mDDRSize || aStartAddr+aSize > mDDRSize) {
        std::cout << "Read size " << std::dec << aSize << " from address 0x" << std::hex << aStartAddr <<
          " goes beyond the device memory" << std::endl;
        return -1;
      }

      endAddr = aSize == 0 ? mDDRSize : aStartAddr + aSize;
      size = endAddr-aStartAddr;

      // Use plain POSIX open/pwrite/close.

      std::cout << "INFO: Writing DDR with " << std::dec << size << " bytes of pattern: 0x"
         << std::hex << aPattern << " from address 0x" <<std::hex << aStartAddr << std::endl;

      unsigned long long count = size;
      uint64_t incr;
      std::memset(buf, aPattern, blockSize);
      for(uint64_t phy=aStartAddr; phy<endAddr; phy+=incr) {
        incr = (count >= blockSize) ? blockSize : count;
        //std::cout << "Writing to addr " << std::hex << phy << " size = " << std::hex << incr << std::dec << std::endl;
        if (xclUnmgdPwrite(mHandle, 0, buf, incr, phy) < 0) {
          //error
          std::cout << "Error (" << strerror (errno) << ") writing 0x" << std::hex << incr << " bytes to DDR at offset 0x" << std::hex << phy << std::dec << "\n";
          return -1;
        }
        count -= incr;
      }

      if (count != 0) {
        std::cout << "Error! Written " << std::dec << size-count << " bytes, requested " << size << std::endl;
        return -1;
      }
      return count;
    }
  };
}
