/*
 * Copyright (C) 2017 Xilinx, Inc
 * Performance Monitoring using PCIe for AWS HAL Driver
 */

#include "shim.h"
#include "perfmon_parameters.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <cstdio>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <thread>
#include <vector>
#include <time.h>
#include <string.h>

#ifdef _WINDOWS
#define __func__ __FUNCTION__
#endif

namespace awsbwhal {
  // ****************
  // Helper functions
  // ****************

  unsigned AwsXcl::getBankCount() {
    return mDeviceInfo.mDDRBankCount;
  }

  void AwsXcl::xclSetProfilingNumberSlots(xclPerfMonType type, uint32_t numSlots) {
    if (type == XCL_PERF_MON_OCL_REGION)
      mOclRegionProfilingNumberSlots = numSlots;
  }

  // Get host timestamp to write to APM
  // IMPORTANT NOTE: this *must* be compatible with the method of generating
  // timestamps as defined in RTProfile::getTraceTime()
  uint64_t AwsXcl::getHostTraceTimeNsec() {
    struct timespec now;
    int err;
    if ((err = clock_gettime(CLOCK_MONOTONIC, &now)) < 0)
      return 0;

    return (uint64_t) now.tv_sec * 1000000000UL + (uint64_t) now.tv_nsec;
  }

  uint64_t AwsXcl::getPerfMonBaseAddress(xclPerfMonType type) {
    if (type == XCL_PERF_MON_MEMORY) return PERFMON0_OFFSET;
    if (type == XCL_PERF_MON_HOST_INTERFACE) return PERFMON1_OFFSET;
    if (type == XCL_PERF_MON_OCL_REGION) return PERFMON2_OFFSET;
    return 0;
  }

  uint64_t AwsXcl::getPerfMonFifoBaseAddress(xclPerfMonType type, uint32_t fifonum) {
    if (type == XCL_PERF_MON_MEMORY) {
      return PERFMON0_OFFSET + XPAR_AXI_PERF_MON_0_TRACE_OFFSET_0;
    }
    if (type == XCL_PERF_MON_OCL_REGION) {
      if (fifonum == 0) return (PERFMON2_OFFSET + XPAR_AXI_PERF_MON_2_TRACE_OFFSET_0);
      if (fifonum == 1) return (PERFMON2_OFFSET + XPAR_AXI_PERF_MON_2_TRACE_OFFSET_1);
      if (fifonum == 2) return (PERFMON2_OFFSET + XPAR_AXI_PERF_MON_2_TRACE_OFFSET_2);
      return 0;
    }
    return 0;
  }

  uint64_t AwsXcl::getPerfMonFifoReadBaseAddress(xclPerfMonType type, uint32_t fifonum) {
    if (type == XCL_PERF_MON_MEMORY) {
      // Use AXI-MM to access trace FIFO
      return XPAR_AXI_PERF_MON_0_TRACE_OFFSET_AXI_FULL;
    }
    if (type == XCL_PERF_MON_OCL_REGION) {
      if (fifonum == 0) return (PERFMON2_OFFSET + XPAR_AXI_PERF_MON_2_TRACE_OFFSET_0);
      if (fifonum == 1) return (PERFMON2_OFFSET + XPAR_AXI_PERF_MON_2_TRACE_OFFSET_1);
      if (fifonum == 2) return (PERFMON2_OFFSET + XPAR_AXI_PERF_MON_2_TRACE_OFFSET_2);
      return 0;
    }
    return 0;
  }

  uint32_t AwsXcl::getPerfMonNumberFifos(xclPerfMonType type) {
    if (type == XCL_PERF_MON_MEMORY)
      return XPAR_AXI_PERF_MON_0_TRACE_NUMBER_FIFO;
    if (type == XCL_PERF_MON_HOST_INTERFACE)
      return XPAR_AXI_PERF_MON_1_TRACE_NUMBER_FIFO;
    if (type == XCL_PERF_MON_OCL_REGION) {
      if (mOclRegionProfilingNumberSlots > 4)
        return 3;
      else
        return 2;
    }
    return 0;
  }

  uint32_t AwsXcl::getPerfMonNumberSlots(xclPerfMonType type) {
    if (type == XCL_PERF_MON_MEMORY) {
      return (getBankCount() + 1);
    }
    if (type == XCL_PERF_MON_HOST_INTERFACE) {
      return XPAR_AXI_PERF_MON_1_NUMBER_SLOTS;
    }
    if (type == XCL_PERF_MON_OCL_REGION) {
      return mOclRegionProfilingNumberSlots;
    }
    return 1;
  }

  uint32_t AwsXcl::getPerfMonNumberSamples(xclPerfMonType type) {
    if (type == XCL_PERF_MON_MEMORY) return XPAR_AXI_PERF_MON_0_TRACE_NUMBER_SAMPLES;
    if (type == XCL_PERF_MON_HOST_INTERFACE) return XPAR_AXI_PERF_MON_1_TRACE_NUMBER_SAMPLES;
    if (type == XCL_PERF_MON_OCL_REGION) return XPAR_AXI_PERF_MON_2_TRACE_NUMBER_SAMPLES;
    return 0;
  }

  uint32_t AwsXcl::getPerfMonByteScaleFactor(xclPerfMonType type) {
    return 1;
  }

  uint8_t AwsXcl::getPerfMonShowIDS(xclPerfMonType type) {
    if (type == XCL_PERF_MON_MEMORY) {
      if (getBankCount() > 1)
        return XPAR_AXI_PERF_MON_0_SHOW_AXI_IDS_2DDR;
      return XPAR_AXI_PERF_MON_0_SHOW_AXI_IDS;
    }
    if (type == XCL_PERF_MON_HOST_INTERFACE) {
      return XPAR_AXI_PERF_MON_1_SHOW_AXI_IDS;
    }
    if (type == XCL_PERF_MON_OCL_REGION) {
      return XPAR_AXI_PERF_MON_2_SHOW_AXI_IDS;
    }
    return 0;
  }

  uint8_t AwsXcl::getPerfMonShowLEN(xclPerfMonType type) {
    if (type == XCL_PERF_MON_MEMORY) {
      if (getBankCount() > 1)
        return XPAR_AXI_PERF_MON_0_SHOW_AXI_LEN_2DDR;
      return XPAR_AXI_PERF_MON_0_SHOW_AXI_LEN;
    }
    if (type == XCL_PERF_MON_HOST_INTERFACE) {
      return XPAR_AXI_PERF_MON_1_SHOW_AXI_LEN;
    }
    if (type == XCL_PERF_MON_OCL_REGION) {
      return XPAR_AXI_PERF_MON_2_SHOW_AXI_LEN;
    }
    return 0;
  }

  uint32_t AwsXcl::getPerfMonSlotStartBit(xclPerfMonType type, uint32_t slotnum) {
    // NOTE: ID widths also set to 5 in HEAD/data/sdaccel/board_support/alpha_data/common/xclplat/xclplat_ip.tcl
    uint32_t bitsPerID = 5;
    uint8_t showIDs = getPerfMonShowIDS(type);
    uint8_t showLen = getPerfMonShowLEN(type);
    uint32_t bitsPerSlot = 10 + (bitsPerID * 4 * showIDs) + (16 * showLen);
    return (18 + (bitsPerSlot * slotnum));
  }

  uint32_t AwsXcl::getPerfMonSlotDataWidth(xclPerfMonType type, uint32_t slotnum) {
    if (slotnum == 0) return XPAR_AXI_PERF_MON_0_SLOT0_DATA_WIDTH;
    if (slotnum == 1) return XPAR_AXI_PERF_MON_0_SLOT1_DATA_WIDTH;
    if (slotnum == 2) return XPAR_AXI_PERF_MON_0_SLOT2_DATA_WIDTH;
    if (slotnum == 3) return XPAR_AXI_PERF_MON_0_SLOT3_DATA_WIDTH;
    if (slotnum == 4) return XPAR_AXI_PERF_MON_0_SLOT4_DATA_WIDTH;
    if (slotnum == 5) return XPAR_AXI_PERF_MON_0_SLOT5_DATA_WIDTH;
    if (slotnum == 6) return XPAR_AXI_PERF_MON_0_SLOT6_DATA_WIDTH;
    if (slotnum == 7) return XPAR_AXI_PERF_MON_0_SLOT7_DATA_WIDTH;
    return XPAR_AXI_PERF_MON_0_SLOT0_DATA_WIDTH;
  }

  // Get the device clock frequency (in MHz)
  double AwsXcl::xclGetDeviceClockFreqMHz() {
    unsigned clockFreq = mDeviceInfo.mOCLFrequency[0];
    if (clockFreq == 0)
      clockFreq = 200;

    //if (mLogStream.is_open())
    //  mLogStream << __func__ << ": clock freq = " << clockFreq << std::endl;
    return ((double)clockFreq);
  }

  // Get the maximum bandwidth for host reads from the device (in MB/sec)
  // NOTE: for now, set to: (256/8 bytes) * 300 MHz = 9600 MBps
  double AwsXcl::xclGetReadMaxBandwidthMBps() {
    return 9600.0;
  }

  // Get the maximum bandwidth for host writes to the device (in MB/sec)
  // NOTE: for now, set to: (256/8 bytes) * 300 MHz = 9600 MBps
  double AwsXcl::xclGetWriteMaxBandwidthMBps() {
    return 9600.0;
  }

  // Convert binary string to decimal
  uint32_t AwsXcl::bin2dec(std::string str, int start, int number) {
    return bin2dec(str.c_str(), start, number);
  }

  // Convert binary char * to decimal
  uint32_t AwsXcl::bin2dec(const char* ptr, int start, int number) {
    const char* temp_ptr = ptr + start;
    uint32_t value = 0;
    int i = 0;

    do {
      if (*temp_ptr != '0' && *temp_ptr!= '1')
        return value;
      value <<= 1;
      if(*temp_ptr=='1')
        value += 1;
      i++;
      temp_ptr++;
    } while (i < number);

    return value;
  }

  // Convert decimal to binary string
  // NOTE: length of string is always sizeof(uint32_t) * 8
  std::string AwsXcl::dec2bin(uint32_t n) {
    char result[(sizeof(uint32_t) * 8) + 1];
    unsigned index = sizeof(uint32_t) * 8;
    result[index] = '\0';

    do {
      result[ --index ] = '0' + (n & 1);
    } while (n >>= 1);

    for (int i=index-1; i >= 0; --i)
      result[i] = '0';

    return std::string( result );
  }

  // Convert decimal to binary string of length bits
  std::string AwsXcl::dec2bin(uint32_t n, unsigned bits) {
    char result[bits + 1];
    unsigned index = bits;
    result[index] = '\0';

    do result[ --index ] = '0' + (n & 1);
    while (n >>= 1);

    for (int i=index-1; i >= 0; --i)
      result[i] = '0';

    return std::string( result );
  }

  // Reset all APM trace AXI stream FIFOs
  size_t AwsXcl::resetFifos(xclPerfMonType type) {
    uint64_t resetCoreAddress[] = {
        getPerfMonFifoBaseAddress(type, 0) + AXI_FIFO_SRR,
        getPerfMonFifoBaseAddress(type, 1) + AXI_FIFO_SRR,
        getPerfMonFifoBaseAddress(type, 2) + AXI_FIFO_SRR
    };

    uint64_t resetFifoAddress[] = {
        getPerfMonFifoBaseAddress(type, 0) + AXI_FIFO_RDFR,
        getPerfMonFifoBaseAddress(type, 1) + AXI_FIFO_RDFR,
        getPerfMonFifoBaseAddress(type, 2) + AXI_FIFO_RDFR
    };

    size_t size = 0;
    uint32_t regValue = AXI_FIFO_RESET_VALUE;

    for (int f=0; f < XPAR_AXI_PERF_MON_0_TRACE_NUMBER_FIFO; f++) {
      size += xclWrite(XCL_ADDR_SPACE_DEVICE_PERFMON, resetCoreAddress[f], &regValue, 4);
      size += xclWrite(XCL_ADDR_SPACE_DEVICE_PERFMON, resetFifoAddress[f], &regValue, 4);
    }

    return size;
  }

  // ********
  // Counters
  // ********

  // Start device counters performance monitoring
  size_t AwsXcl::xclPerfMonStartCounters(xclPerfMonType type) {
    if (mLogStream.is_open()) {
      mLogStream << __func__ << ", " << std::this_thread::get_id() << ", "
          << type << ", This driver is not supported ." << std::endl;
    }
    return 0;
  }

  // Stop both profile and trace performance monitoring
  size_t AwsXcl::xclPerfMonStopCounters(xclPerfMonType type) {
    if (mLogStream.is_open()) {
      mLogStream << __func__ << ", " << std::this_thread::get_id() << ", "
          << type << ", This driver is not supported .." << std::endl;
    }
    return 0;
  }

  // Read APM performance counters
  size_t AwsXcl::xclPerfMonReadCounters(xclPerfMonType type, xclCounterResults& counterResults) {
    if (mLogStream.is_open()) {
      mLogStream << __func__ << ", " << std::this_thread::get_id()
      << ", " << type << ", " << &counterResults
      << ", This driver is not supported .." << std::endl;
    }
    return 0;
  }

  // *****
  // Trace
  // *****

  // Clock training used in converting device trace timestamps to host domain
  size_t AwsXcl::xclPerfMonClockTraining(xclPerfMonType type) {
    if (mLogStream.is_open()) {
      mLogStream << __func__ << ", " << std::this_thread::get_id() << ", "
          << type << ", Send clock training..." << std::endl;
    }

    size_t size = 0;
    uint64_t baseAddress = getPerfMonBaseAddress(type);

    // Send host timestamps to target device
    // NOTE: this is used for training to interpolate between time domains
    for (int i=0; i < 3; i++) {
#if 1
      uint64_t hostTimeNsec = getHostTraceTimeNsec();

      uint32_t hostTimeHigh = hostTimeNsec >> 32;
      uint32_t hostTimeLow  = hostTimeNsec & 0xffffffff;
#else
      // Test values
      uint32_t hostTimeHigh = 0xf00df00d;
      uint32_t hostTimeLow  = 0xdeadbeef;
#endif

      // Send upper then lower 32 bits of host timestamp to APM SW data register
      size += xclWrite(XCL_ADDR_SPACE_DEVICE_PERFMON, baseAddress + XAPM_SWD_OFFSET, &hostTimeHigh, 4);
      size += xclWrite(XCL_ADDR_SPACE_DEVICE_PERFMON, baseAddress + XAPM_SWD_OFFSET, &hostTimeLow, 4);

      if (mLogStream.is_open()) {
        mLogStream << "  Host timestamp: 0x" << std::hex << hostTimeHigh
            << " " << hostTimeLow << std::dec << std::endl;
      }
    }

    return size;
  }

  // Start trace performance monitoring
  size_t AwsXcl::xclPerfMonStartTrace(xclPerfMonType type, uint32_t startTrigger) {
    if (mLogStream.is_open()) {
      mLogStream << __func__ << ", " << std::this_thread::get_id()
      << ", " << type << ", " << startTrigger
      << ", This driver is not supported .." << std::endl;
    }
    return 0;
  }

  // Stop trace performance monitoring
  size_t AwsXcl::xclPerfMonStopTrace(xclPerfMonType type) {
    if (mLogStream.is_open()) {
      mLogStream << __func__ << ", " << std::this_thread::get_id() << ", "
          << type << ", This driver is not supported .." << std::endl;
    }
    return 0;
  }

  // Get trace word count
  uint32_t AwsXcl::xclPerfMonGetTraceCount(xclPerfMonType type) {
    if (mLogStream.is_open()) {
      mLogStream << __func__ << ", " << std::this_thread::get_id()
      << ", " << type << std::endl;
    }
    return 0;
  }

  // Read all values from APM trace AXI stream FIFOs
  size_t AwsXcl::xclPerfMonReadTrace(xclPerfMonType type, xclTraceResultsVector& traceVector) {
    if (mLogStream.is_open()) {
      mLogStream << __func__ << ", " << std::this_thread::get_id()
      << ", " << type << ", " << &traceVector
      << ", This driver is not supported .." << std::endl;
    }

    traceVector.mLength = 0;
    return 0;
  } // end xclPerfMonReadTrace

} // namespace awsbwhal


size_t xclPerfMonStartCounters(xclDeviceHandle handle, xclPerfMonType type)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return -1;
  return drv->xclPerfMonStartCounters(type);
}


size_t xclPerfMonStopCounters(xclDeviceHandle handle, xclPerfMonType type)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return -1;
  return drv->xclPerfMonStopCounters(type);
}


size_t xclPerfMonReadCounters(xclDeviceHandle handle, xclPerfMonType type, xclCounterResults& counterResults)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return -1;
  return drv->xclPerfMonReadCounters(type, counterResults);
}


size_t xclPerfMonClockTraining(xclDeviceHandle handle, xclPerfMonType type)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return -1;
  return drv->xclPerfMonClockTraining(type);
}


size_t xclPerfMonStartTrace(xclDeviceHandle handle, xclPerfMonType type, uint32_t startTrigger)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return -1;
  return drv->xclPerfMonStartTrace(type, startTrigger);
}


size_t xclPerfMonStopTrace(xclDeviceHandle handle, xclPerfMonType type)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return -1;
  return drv->xclPerfMonStopTrace(type);
}


uint32_t xclPerfMonGetTraceCount(xclDeviceHandle handle, xclPerfMonType type)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return -1;
  return drv->xclPerfMonGetTraceCount(type);
}


size_t xclPerfMonReadTrace(xclDeviceHandle handle, xclPerfMonType type, xclTraceResultsVector& traceVector)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return -1;
  return drv->xclPerfMonReadTrace(type, traceVector);
}


double xclGetDeviceClockFreqMHz(xclDeviceHandle handle)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return 0.0;
  return drv->xclGetDeviceClockFreqMHz();
}


double xclGetReadMaxBandwidthMBps(xclDeviceHandle handle)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return 0.0;
  return drv->xclGetReadMaxBandwidthMBps();
}


double xclGetWriteMaxBandwidthMBps(xclDeviceHandle handle)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return 0.0;
  return drv->xclGetWriteMaxBandwidthMBps();
}


size_t xclGetDeviceTimestamp(xclDeviceHandle handle)
{
  return 0;
}


void xclSetProfilingNumberSlots(xclDeviceHandle handle, xclPerfMonType type, uint32_t numSlots)
{
  awsbwhal::AwsXcl *drv = awsbwhal::AwsXcl::handleCheck(handle);
  if (!drv)
    return;
  return drv->xclSetProfilingNumberSlots(type, numSlots);
}


uint32_t xclGetProfilingNumberSlots(xclDeviceHandle handle, xclPerfMonType type)
{
  return 2;
}


void xclGetProfilingSlotName(xclDeviceHandle handle, xclPerfMonType type, uint32_t slotnum,
		                     char* slotName, uint32_t length)
{
  const char* name = (slotnum == XPAR_SPM0_HOST_SLOT) ? "Host" : "Kernels";
  strncpy(slotName, name, length);
}


void xclWriteHostEvent(xclDeviceHandle handle, xclPerfMonEventType type,
                       xclPerfMonEventID id)
{
  // don't do anything
}

// 67d7842dbbe25473c3c32b93c0da8047785f30d78e8a024de1b57352245f9689
